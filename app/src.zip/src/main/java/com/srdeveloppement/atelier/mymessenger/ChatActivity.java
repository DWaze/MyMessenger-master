package com.srdeveloppement.atelier.mymessenger;

import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.text.Editable;
import android.text.Spannable;
import android.text.SpannableStringBuilder;
import android.text.TextWatcher;
import android.text.style.ImageSpan;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ToggleButton;

import java.util.ArrayList;
import java.util.Calendar;

public class ChatActivity extends AppCompatActivity {
    private RecyclerView mRecyclerView;
    private RecyclerView.Adapter mAdapter;
    private RecyclerView.LayoutManager mLayoutManager;
    EditText area;
    Button send;
    public static String emojiValue;
    public Drawable textDrawable;
public ImageView pub_iv;
    String SenderMsg;
    String ReciverrMsg;
    Intent intent;
    TextView senderTv;
    TextView reciverTv;
    ToggleButton toggle,closeOpen;
    int a;
    ImageView em1,em2,em3,em4,em5,em6,em7;
    LinearLayout emojiPanel;
    ArrayList<Discution> Disc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        mRecyclerView = (RecyclerView) findViewById(R.id.chat);
        emojiPanel = (LinearLayout) findViewById(R.id.emojiPanel);
        em2=(ImageView)findViewById(R.id.em2);
        em3=(ImageView)findViewById(R.id.em3);
        em4=(ImageView)findViewById(R.id.em4);
        em5=(ImageView)findViewById(R.id.em5);
        em6=(ImageView)findViewById(R.id.em6);
        em7=(ImageView)findViewById(R.id.em7);
        closeOpen = (ToggleButton) findViewById(R.id.closeOpen);
        closeOpen.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    emojiPanel.setVisibility(View.VISIBLE);
                } else {
                    emojiPanel.setVisibility(View.GONE);

                }
            }
        });

        send = (Button)findViewById(R.id.send);

        mRecyclerView.setHasFixedSize(true);


        mLayoutManager = new LinearLayoutManager(this);

        mRecyclerView.setLayoutManager(mLayoutManager);


        area=(EditText)findViewById(R.id.my_edit_text);
        area.addTextChangedListener(new TextWatcher() {

            public void onTextChanged(CharSequence s, int start, int before, int count) {

                Log.d("key", "onTextChanged start :"+start +"  end :"+count);

            }
            public void beforeTextChanged(CharSequence s, int start, int count,int after) {

                send.setBackgroundResource(R.drawable.send_disabled);
                Log.d("key", "beforeTextChanged start :"+start +"  after :"+after);
            }

            public void afterTextChanged(Editable s) {
                if(  area.getText().toString().trim().equals("")){
                    send.setBackgroundResource(R.drawable.send_disabled);
                }else{
                    send.setBackgroundResource(R.drawable.send);
                    send.setOnClickListener(new View.OnClickListener() {

                        @Override
                        public void onClick(View v) {

                            if(isEmpty(area)){

                            }else{
                                if (toggle.isChecked()) {

                                    //senderTv.setBackground(getResources().getDrawable(R.drawable.mytext_sender));
                                    SenderMsg = area.getText().toString();
                                    Disc.add(new Discution(Calendar.getInstance(),"", false, SenderMsg, true));
                                    // specify an adapter (see also next example)
                                    mAdapter = new MyAdapter(Disc);
                                    mRecyclerView.setAdapter(mAdapter);
                                    mRecyclerView.scrollToPosition(mAdapter.getItemCount() - 1);
                                    area.setText("");
                                    send.setBackgroundResource(R.drawable.send_disabled);


                                }else{

                                    ReciverrMsg = area.getText().toString();
                                    Disc.add(new Discution(Calendar.getInstance(), ReciverrMsg,true,"",false));
                                    // senderTv.setBackgroundResource(R.drawable.transparent);
                                    // specify an adapter (see also next example)
                                    mAdapter = new MyAdapter(Disc);
                                    mRecyclerView.setAdapter(mAdapter);
                                    mRecyclerView.scrollToPosition(mAdapter.getItemCount()-1);
                                    area.setText("");
                                    send.setBackgroundResource(R.drawable.send_disabled);

                                }
                            }


                        }
                    });
                }

                Log.d("key", "afterTextChange last char"+s);
            }

        });


        intent= new Intent(ChatActivity.this, MyAdapter.class);



        Disc = new ArrayList<Discution>();

        senderTv = (TextView)findViewById(R.id.senderText);
        reciverTv = (TextView)findViewById(R.id.reciverText);
        toggle = (ToggleButton) findViewById(R.id.toggleButton);







    }

    public void addEmoji(Drawable drawable) {
        drawable .setBounds(0, 0, 30,30);

        int selectionCursor = area.getSelectionStart();
        area.getText().insert(selectionCursor, emojiValue);
        selectionCursor = area.getSelectionStart();

        SpannableStringBuilder builder = new SpannableStringBuilder(area.getText());
        builder.setSpan(new ImageSpan(drawable), selectionCursor - emojiValue.length(), selectionCursor,                                                   Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        area.setText(builder);
        area.setSelection(selectionCursor);
    }






    boolean isEmpty(EditText etText) {
        return etText.getText().toString().trim().length() == 0;
    }

    public void setEmoji(View view) {
        int imId=view.getId();
        switch (imId){
            case R.id.em2:
                emojiValue=":tongue:";
                addEmoji(em2.getDrawable());
                break;
            case R.id.em3:
                emojiValue=":glasses:";
                addEmoji(em3.getDrawable());
                break;
            case R.id.em4:
                emojiValue=":sad:";
                addEmoji(em4.getDrawable());
                break;
            case R.id.em5:
                emojiValue=":angry:";
                addEmoji(em5.getDrawable());
                break;
            case R.id.em6:
                emojiValue=":laugh:";
                addEmoji(em6.getDrawable());
                break;
            case R.id.em7:
                emojiValue=":happy:";
                addEmoji(em7.getDrawable());
                break;
        }
    }






////////////////////////////////////////////////////////////////////////////////////////////////////
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {getMenuInflater().inflate(R.menu.menu_main, menu);return true;}

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {int id = item.getItemId();if (id == R.id.action_settings) {return true;}return super.onOptionsItemSelected(item);}


}
